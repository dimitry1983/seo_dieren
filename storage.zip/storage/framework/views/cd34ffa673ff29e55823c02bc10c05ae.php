<?php $__env->startSection('content'); ?>

<?php $__env->startSection('structured-data'); ?>
    <script type="application/ld+json">
        {
        "@context": "https://schema.org",
        "@type": "VeterinaryCare",
        "name": "<?php echo e($veterinarian->name); ?>",
        "image": "<?php echo e(asset('storage/' . $veterinarian->image ?? 'dieren/src/public/img/clinic.png')); ?>",
        "description": <?php echo json_encode(strip_tags($veterinarian->description), 15, 512) ?>,
        "address": {
            "@type": "PostalAddress",
            "streetAddress": "<?php echo e($veterinarian->street); ?> <?php echo e($veterinarian->street_nr); ?>",
            "addressLocality": "<?php echo e($veterinarian->city->name); ?>",
            "postalCode": "<?php echo e($veterinarian->zipcode); ?>",
            "addressCountry": "NL"
        },
        "telephone": "<?php echo e($veterinarian->phone); ?>",
        "aggregateRating": {
            "@type": "AggregateRating",
            "ratingValue": "<?php echo e(number_format($veterinarian->rating, 1)); ?>",
            "reviewCount": "<?php echo e($totalRatings); ?>"
        },
        "review": [
            <?php $__currentLoopData = $reviews->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            {
                "@type": "Review",
                "author": {
                "@type": "Person",
                "name": "<?php echo e($review->name); ?>"
                },
                "datePublished": "<?php echo e(\Carbon\Carbon::parse($review->created_at)->toDateString()); ?>",
                "reviewBody": <?php echo json_encode($review->description, 15, 512) ?>,
                "reviewRating": {
                "@type": "Rating",
                "ratingValue": "<?php echo e($review->rating); ?>",
                "bestRating": "5"
                }
            }<?php if(!$loop->last): ?>,<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ]
        }
    </script>
<?php $__env->stopSection(); ?>


<div class="main-container relative w-full overflow-hidden">
    <?php
        $totalRatings = array_sum($ratingCounts);
        $days = [ 'Maandag', 'Dinsdag', 'Woensdag', 'Donderdag', 'Vrijdag', 'Zaterdag', 'Zondag'];

    ?>

    <section class="section section--hero-interior bg-cover bg-right bg-center" style="background-image: url('<?php echo e(asset('dieren/src/public/img/profile.png')); ?>'); min-height: 120px;"></section>

    <section class="section section--profile p-0 mt-[-90px] bg-transparent">
        <div class="container mx-auto">
            <div class="flex items-center">
                <figure>
                    <img src="<?php echo e(asset('dieren/src/public/img/clinic.png')); ?>" alt="">
                </figure>
                <h3 class="title title--profile text-md font-bold ml-4 leading-tight md:leading-tight lg:leading-normal">
                    <?php echo e($veterinarian->name); ?> |
                    <?php echo render_stars($veterinarian->rating); ?>

                    <span><?php echo e(number_format($veterinarian->rating, 1)); ?> - (<?php echo e($totalRatings); ?> <?php echo e(devTranslate('page.beoordelingen','beoordelingen')); ?>)</span>
                </h3>
            </div>
        </div>
        <div class="container mx-auto mt-5">
            <?php echo $__env->make('parts.breadcrumb' , ['breadcrumbs' => $breadcrumbData ?? ''] , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </section>

    <section class="section section--profile-interior">
        <div class="container mx-auto relative">
           
            <div class="grid grid-cols-4 gap-4">
                <div class="lg:col-span-3 col-span-4">
                    <div class="pills border border-gray-300 shadow-lg mb-8">
                        <ul class="flex flex-col md:flex-row flex-wrap w-full py-3">
                        <li class="w-full md:w-auto px-1 xl:px-3 mb-1">
                            <button class="btn btn-primaryLight w-full md:w-auto"><?php echo e(devTranslate('page.Informatie','Informatie')); ?></button>
                        </li>
                        <li class="w-full md:w-auto xl:px-3 md:border-l mb-1 md:border-l-gray-300">
                            <button 
                                onclick="document.getElementById('diensten').scrollIntoView({ behavior: 'smooth' });"
                                class="btn btn-primary bg-white w-full md:w-auto"
                            ><?php echo e(devTranslate('page.Diensten','Diensten')); ?></button>
                        </li>
                        <li class="w-full md:w-auto xl:px-3 md:border-l mb-1 md:border-l-gray-300">
                            <button 
                                onclick="document.getElementById('galerij').scrollIntoView({ behavior: 'smooth' });"
                                class="btn btn-primary bg-white w-full md:w-auto"
                            ><?php echo e(devTranslate('page.Galerij','Galerij')); ?></button>
                        </li>
                        <li class="w-full md:w-auto xl:px-3 md:border-l mb-1 md:border-l-gray-300">
                            <button 
                                onclick="document.getElementById('prijzen').scrollIntoView({ behavior: 'smooth' });"
                                class="btn btn-primary bg-white w-full md:w-auto"
                            ><?php echo e(devTranslate('page.Prijzen','Prijzen')); ?></button>
                        </li>
                        <li class="w-full md:w-auto xl:px-3 md:border-l mb-1 md:border-l-gray-300">
                            <button 
                                onclick="document.getElementById('reviews').scrollIntoView({ behavior: 'smooth' });"
                                class="btn btn-primary bg-white w-full md:w-auto"
                            ><?php echo e(devTranslate('page.Beoordelingen','Beoordelingen')); ?></button>
                        </li>
                    </ul>
                    </div>
                    <div class="content border border-gray-300 shadow-lg px-[30px] py-[50px] mb-6 relative">
                        <h4 class="subtitle w-fit text-md font-semibold relative before:content-[''] before:w-[20px] before:h-[2px] before:bg-primary before:absolute before:right-[-30px] before:top-1/2 before:-translate-y-1/2">
                            <?php echo e(devTranslate('page.Informatie','Informatie')); ?>

                        </h4>
                        <h3 class="title title--section font-bold text-3xl text-gray-800">
                            <span class="text-primary"><?php echo e($veterinarian->name); ?></span>
                        </h3>
                        <p>
                            <?php echo $veterinarian->description; ?>

                        </p>

                        <?php if(!empty($veterinarian->openingstimes)): ?>
                            <h3 class="title title--section font-bold text-3xl mb-4 text-gray-800">
                                <span class="text-primary"><?php echo e(__('Openingstijden')); ?></span>
                            </h3>
                            <ul class="space-y-2">
                                <?php $__currentLoopData = $veterinarian->openingstimes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $times): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="grid grid-cols-3 gap-4">
                                        <span><?php echo e($days[$times->day_of_week]); ?></span>
                                        <span><?php echo e($times->open_time); ?></span>
                                        <span><?php echo e($times->close_time); ?></span>
                                    </li>     
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>


                        <img src="<?php echo e(asset('dieren/src/public/img/paw.png')); ?>" alt="" class="absolute top-[20px] right-[20px] z-[0]">
                    </div>
                    <div class="content border border-gray-300 shadow-lg px-[30px] py-[50px] mb-6 relative" id="diensten">
                        <h4 class="subtitle w-fit text-md font-semibold relative before:content-[''] before:w-[20px] before:h-[2px] before:bg-primary before:absolute before:right-[-30px] before:top-1/2 before:-translate-y-1/2">
                            <?php echo e(devTranslate('page.Diensten','Diensten')); ?>

                        </h4>
                        <h3 class="title title--section font-bold text-3xl text-gray-800 mb-6 leading-tight md:leading-tight lg:leading-normal">
                            <span class="text-primary"><?php echo e(devTranslate('page.Producten','Producten')); ?></span> <?php echo e(devTranslate('page.En Diensten','En Diensten')); ?>

                        </h3>
                        <div class="services grid md:grid-cols-2 lg:grid-cols-4 gap-2">
                            <?php if(!empty($veterinarian->services)): ?> 
                                <?php $__currentLoopData = $veterinarian->services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="services mb-4 border-2 border-white shadow-lg bg-white transition-transform duration-300 ease-out hover:scale-y-105">
                                        <figure class="bg-gray-300 w-full h-[170px] flex overflow-hidden">
                                            <img class="m-auto w-full h-full object-cover" src="<?php echo e(asset('storage/'.$item->image)); ?>" alt="">
                                        </figure>
                                        <div class="content text-center p-4">
                                            <h3 class="title text-md font-semibold mb-2"><?php echo e($item->name); ?></h3>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                        <img src="<?php echo e(asset('dieren/src/public/img/paw.png')); ?>" alt="" class="absolute top-[20px] right-[20px] z-[0]">
                    </div>
                    <div class="gallery border border-gray-300 shadow-lg px-[30px] py-[50px] mb-6 relative" id="galerij">
                        <h4 class="subtitle w-fit text-md font-semibold relative before:content-[''] before:w-[20px] before:h-[2px] before:bg-primary before:absolute before:right-[-30px] before:top-1/2 before:-translate-y-1/2">
                            <?php echo e(devTranslate('page.Galerij','Galerij')); ?>

                        </h4>
                        <h3 class="title title--section font-bold text-3xl text-gray-800 mb-6 leading-tight md:leading-tight lg:leading-normal">
                            <span class="text-primary"><?php echo e(devTranslate('page.Sfeer','Sfeer')); ?></span> <?php echo e(devTranslate('page.Impressie','Impressie')); ?>

                        </h3>
                        <div class="splide" id="gallery-slider">
                            <div class="splide__track">
                                <ul class="splide__list">
                                    <li class="splide__slide">
                                        <img class="w-full" src="<?php echo e(asset('dieren/src/public/img/gallery-1.png')); ?>" alt="">
                                    </li>
                                    <li class="splide__slide">
                                        <img class="w-full" src="<?php echo e(asset('dieren/src/public/img/gallery-2.png')); ?>" alt="">
                                    </li>
                                    <li class="splide__slide">
                                        <img class="w-full" src="<?php echo e(asset('dieren/src/public/img/gallery-3.png')); ?>" alt="">
                                    </li>
                                    <li class="splide__slide">
                                        <img class="w-full" src="<?php echo e(asset('dieren/src/public/img/gallery-1.png')); ?>" alt="">
                                    </li>
                                    <li class="splide__slide">
                                        <img class="w-full" src="<?php echo e(asset('dieren/src/public/img/gallery-2.png')); ?>" alt="">
                                    </li>
                                    <li class="splide__slide">
                                        <img class="w-full" src="<?php echo e(asset('dieren/src/public/img/gallery-3.png')); ?>" alt="">
                                    </li>
                                </ul>
                            </div>
                        </div>

                        <img src="<?php echo e(asset('dieren/src/public/img/paw.png')); ?>" alt="" class="absolute top-[20px] right-[20px] z-[0]">
                    </div>
                    <div class="prices border border-gray-300 shadow-lg px-[30px] py-[50px] mb-6 relative" id="prijzen">
                        <h4 class="subtitle w-fit text-md font-semibold relative before:content-[''] before:w-[20px] before:h-[2px] before:bg-primary before:absolute before:right-[-30px] before:top-1/2 before:-translate-y-1/2">
                            <?php echo e(devTranslate('page.Prijzen','Prijzen')); ?>

                        </h4>
                        <h3 class="title title--section font-bold text-3xl text-gray-800 mb-6 leading-tight md:leading-tight lg:leading-normal">
                            <span class="text-primary"><?php echo e(devTranslate('page.Wat kunt u','Wat kunt u')); ?></span> <?php echo e(devTranslate('page.Verwachten','Verwachten')); ?>

                        </h3>
                        <div class="grid grid-cols-1 lg:grid-cols-2 gap-4">
                            <div class="lg:col-span-1 border-gray-300 shadow-lg px-[30px] py-[50px] mb-6">
                                <figure class="w-[77px] h-[77px] bg-primaryLight rounded-full flex justify-center items-center mt-[-60px] mb-2">
                                    <img src="<?php echo e(asset('dieren/src/public/img/icon1.png')); ?>" alt="">
                                </figure>
                                <h3 class="title title--services text-2xl font-bold text-gray-800 mb-4">
                                    <?php echo e(devTranslate('page.Diensten','Diensten')); ?>

                                </h3>
                                <ul>
                                    <li class="mb-3 flex">
                                        <i class="fa-regular fa-circle-check text-primary mr-1"></i> Overleg <span class="price block ml-auto">€35,00</span>
                                    </li>

                                    <li class="mb-3 flex">
                                        <i class="fa-regular fa-circle-check text-primary mr-1"></i> Vaccins <span class="price block ml-auto">€35,00</span>
                                    </li>
                                    <li class="mb-3 flex">
                                        <i class="fa-regular fa-circle-check text-primary mr-1"></i> Ontwormen <span class="price block ml-auto">€35,00</span>
                                    </li>
                                    <li class="mb-3 flex">
                                        <i class="fa-regular fa-circle-check text-primary mr-1"></i> Elektrocardiogram <span class="price block ml-auto">€35,00</span>
                                    </li>
                                    <li class="mb-3 flex">
                                        <i class="fa-regular fa-circle-check text-primary mr-1"></i> Voedingsadvies <span class="price block ml-auto">€35,00</span>
                                    </li>
                                    <li class="mb-3 flex">
                                        <i class="fa-regular fa-circle-check text-primary mr-1"></i> Accessoires <span class="price block ml-auto">€35,00</span>
                                    </li>
                                </ul>
                            </div>
                            <div class="lg:col-span-1 border-gray-300 shadow-lg px-[30px] py-[50px] mb-6">
                                <figure class="w-[77px] h-[77px] bg-primaryLight rounded-full flex justify-center items-center mt-[-60px] mb-2">
                                    <img src="<?php echo e(asset('dieren/src/public/img/icon2.png')); ?>" alt="">
                                </figure>
                                <h3 class="title title--services text-2xl font-bold text-gray-800 mb-4">
                                    Operaties / Sterilisaties
                                </h3>
                                <ul>
                                    <li class="mb-3 flex">
                                        <i class="fa-regular fa-circle-check text-primary mr-1"></i> 0 A 5kg <span class="price block ml-auto">€35,00</span>
                                    </li>
                                    <li class="mb-3 flex">
                                        <i class="fa-regular fa-circle-check text-primary mr-1"></i> 5.1 A 15kg <span class="price block ml-auto">€35,00</span>
                                    </li>
                                    <li class="mb-3 flex">
                                        <i class="fa-regular fa-circle-check text-primary mr-1"></i> 15.1 A 25kg <span class="price block ml-auto">€35,00</span>
                                    </li>
                                    <li class="mb-3 flex">
                                        <i class="fa-regular fa-circle-check text-primary mr-1"></i> 25.1 A 25kg <span class="price block ml-auto">€35,00</span>
                                    </li>
                                    <li class="mb-3 flex">
                                        <i class="fa-regular fa-circle-check text-primary mr-1"></i> 35.1 A 45kg <span class="price block ml-auto">€35,00</span>
                                    </li>
                                    <li class="mb-3 flex">
                                        <i class="fa-regular fa-circle-check text-primary mr-1"></i> > A 45kg <span class="price block ml-auto">€35,00</span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <img src="<?php echo e(asset('dieren/src/public/img/paw.png')); ?>" alt="" class="absolute top-[20px] right-[20px] z-[0]">
                    </div>
                    <div class="reviews border border-gray-300 shadow-lg px-[30px] py-[50px] mb-6 relative" id="reviews">
                        <h4 class="subtitle w-fit text-md font-semibold relative before:content-[''] before:w-[20px] before:h-[2px] before:bg-primary before:absolute before:right-[-30px] before:top-1/2 before:-translate-y-1/2">
                            <?php echo e(devTranslate('page.Beoordelingen','Beoordelingen')); ?>

                        </h4>
                        <h3 class="title title--section font-bold text-3xl text-gray-800 mb-6 leading-tight md:leading-tight lg:leading-normal">
                            <span class="text-primary"><?php echo e(devTranslate('page.Wat andere mensen','Wat andere mensen')); ?></span> <?php echo e(devTranslate('page.Vonden','Vonden')); ?>

                        </h3>


                        
                        <div class="rate grid lg:grid-cols-3 grid-cols-1 mb-4 pb-6 border-b border-b-gray-300">
                            <div class="lg:col-span-1 col-span-3">
                                <h4 class="qualify font-bold text-2xl">
                                    <?php echo e(number_format($rating, 1)); ?>

                                </h4>
                                <h4 class="starts text-yellow-500 text-lg">
                                    <?php echo render_stars($rating); ?>

                                </h4>
                                <p class="font-bold">
                                    <?php echo e(number_format($rating, 1)); ?> - (<?php echo e($totalRatings); ?> <?php echo e(devTranslate('page.beoordelingen','beoordelingen')); ?>)
                                </p>
                            </div>

                            <div class="col-span-3 lg:col-span-2">
                                <?php $__currentLoopData = [5, 4, 3, 2, 1]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $star): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $count = $ratingCounts[$star] ?? 0;
                                        $percentage = $totalRatings > 0 ? ($count / $totalRatings) * 100 : 0;
                                    ?>
                                    <div class="flex items-center gap-2 <?php echo e($star !== 5 ? 'mt-2' : ''); ?>">
                                        <span class="text-gray-800 font-semibold w-[90px]"><?php echo e($star); ?> <?php echo e(devTranslate('page.Stars','Sterren')); ?></span>
                                        <div class="relative w-full h-6 bg-gray-200 rounded-lg overflow-hidden flex items-center">
                                            <div class="absolute left-0 top-0 h-full bg-yellow-500" style="width: <?php echo e($percentage); ?>%"></div>
                                        </div>
                                        <span class="text-gray-800 font-semibold"><?php echo e($count); ?></span>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>

                        <div class="reviews">
                            
                        <?php if(!empty($reviews[0])): ?>
                            <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="review pb-6 mb-4 border-b border-b-gray-300">
                                    <p class="text-gray-700 date">
                                        <?php echo e(\Carbon\Carbon::parse($review->created_at)->translatedFormat('F d, Y')); ?>

                                    </p>

                                    <h4 class="starts text-yellow-500 text-lg mb-2">
                                        <?php echo render_stars($review->rating); ?>

                                        <span class="text-black font-bold"><?php echo e(number_format($review->rating, 1)); ?></span>
                                    </h4>

                                    <h3 class="name text-lg font-bold mb-2">
                                        <?php echo e($review->name); ?>, <?php echo e($review->city); ?>

                                    </h3>

                                    <p><?php echo e($review->description); ?></p>
                                    <?php if($review->type == 'Google'): ?>
                                        <div class="mt-2 inline-flex items-center text-sm text-blue-600 bg-blue-100 px-2 py-1 rounded-full">
                                            <i class="fa-brands fa-google mr-1"></i> Google review
                                        </div>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <div class="text-center py-10 text-gray-500">
                                <p class="text-lg font-semibold"><?php echo e(devTranslate('page.No reviews found','Geen recencies gevonden.')); ?></p>
                            </div>
                        <?php endif; ?>

                        <?php if(!empty($reviews[0])): ?>
                            <div class="pagination flex justify-center gap-2">
                                <?php echo e($reviews->appends(request()->query())->links('vendor.pagination.custom')); ?>

                            </div>
                        <?php endif; ?>
                        </div>
                        <img src="<?php echo e(asset('dieren/src/public/img/paw.png')); ?>" alt="" class="absolute top-[20px] right-[20px] z-[0]">
                    </div>
                </div>
                <div class="lg:col-span-1 col-span-4">
                    <div class="sidebar border border-gray-300 transition duration-300 ease-out shadow-lg">
                        <div class="map">
                            <?php if($veterinarian->lat && $veterinarian->lon): ?>
                                <div class="w-full h-[300px] rounded overflow-hidden shadow-lg">
                                    <iframe 
                                        width="100%" 
                                        height="100%" 
                                        frameborder="0" 
                                        style="border:0" 
                                        src="https://maps.google.com/maps?q=<?php echo e($veterinarian->lat); ?>,<?php echo e($veterinarian->lon); ?>&hl=nl&z=15&output=embed" 
                                        allowfullscreen>
                                    </iframe>
                                </div>
                            <?php else: ?>
                                <p class="text-sm text-gray-500">Locatie niet beschikbaar</p>
                            <?php endif; ?>
                        </div>
                        <div class="content py-3 px-2">
                            <h3 class="title title--block font-bold text-sm mb-3">
                                <?php echo e($veterinarian->name); ?>

                            </h3>
                            <p class="location text-xs mb-0">
                                <i class="fa-solid fa-location-dot text-primary"></i>         <?php echo e($veterinarian->zipcode); ?> <?php echo e($veterinarian->street); ?> <?php echo e($veterinarian->street_nr); ?> <br/> <?php echo e($veterinarian->city->name); ?>, Nederland
                            </p>
                            <a class="text-xs" href="#">
                                <i class="fa-solid fa-phone text-primary"></i> <?php echo e($veterinarian->phone); ?>

                            </a>
                            <p>
                                <?php if($veterinarian->user_id == 1): ?>
                                    <a href="<?php echo e(route('register')); ?>" class="text-primary underline"><?php echo e(__('Account claimen')); ?></a>
                                <?php else: ?>

                                <?php endif; ?>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <img src="<?php echo e(asset('dieren/src/public/img/bg-blocks.png')); ?>" alt="" class="absolute top-0 bottom-0 right-0 z-[-1] m-auto">
</div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/dierenartsen/dierenartsen/resources/views/website/profile.blade.php ENDPATH**/ ?>