<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('dieren-dashboard/src/public/css/quill.snow.css')); ?>">
    
    <link rel="stylesheet" href="<?php echo e(asset('dieren/src/public/css/splide.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('dieren-dashboard/src/public/css/all.min.css')); ?>">

    <link href="/css/filament/filament/app.css?v=3.2.132.0" rel="stylesheet" data-navigate-track />
    <?php echo \Filament\Support\Facades\FilamentAsset::renderStyles() ?> 
    <link rel="stylesheet" href="<?php echo e(asset('dieren-dashboard/dist/public/css/app.css')); ?>">
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

    <?php echo $__env->yieldPushContent('styles'); ?> <!-- For page-specific styles -->

    <style>
        :root {
            --primary: #3ec0bf;
            --primaryLight:rgb(96, 236, 236);
            --primaryDark:rgb(12, 141, 141);
            --primaryDarker:rgb(0, 86, 86);
            --secondary: #E8FF57;
            --secondaryLight: #FFFF7F;
            --secondaryDark: #A6BE1B;
            --secondaryDarker: #86A600;
        }
    </style>

</head>

<body class="text-base">
    <?php echo $__env->make('parts.company.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo e($slot); ?>

</body>
<?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

<?php echo \Filament\Support\Facades\FilamentAsset::renderScripts() ?>
    <link rel="stylesheet" type="text/css" href="http://localhost:8000/_filepond/styles?v=1.4.1">
    <script type="module" src="http://localhost:8000/_filepond/scripts?v=1.4.1" data-navigate-once defer data-navigate-track></script> 
<script src="<?php echo e(asset('dieren-dashboard/src/public/js/quill.js')); ?>"></script>

<?php echo $__env->make('parts.company.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->yieldPushContent('js'); ?>

</html><?php /**PATH /Applications/MAMP/htdocs/dierenartsen/dierenartsen/resources/views/layouts/company.blade.php ENDPATH**/ ?>