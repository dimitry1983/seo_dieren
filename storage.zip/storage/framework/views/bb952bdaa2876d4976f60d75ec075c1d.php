<?php echo e($slot); ?>

<?php /**PATH /Applications/MAMP/htdocs/dierenartsen/dierenartsen/resources/views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>