<?php $__env->startSection('content'); ?>
<div class="main-container center bg-white text-white py-6 lg:py-20 h-[60vh]">
    <div class="container text-center mx-auto px-4">
        <div class="error-title"><h1 class="text-[#099] text-5xl font-bold">404</h1></div>
        <div class="error-subtitle text-gray-800">Oops! Page Not Found</div>
        <div class="error-message text-gray-800">Sorry, but the page you are looking for does not exist.</div>
        <a href="<?php echo e(url('/')); ?>" class="btn btn-primary mt-4 block mx-auto w-fit">Go to Home</a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/dierenartsen/dierenartsen/resources/views/errors/404.blade.php ENDPATH**/ ?>