<?php $__env->startSection('content'); ?>
    <div class="main-container relative w-full overflow-hidden">
        <section class="section section--hero-interior bg-[url('../../../src/public/img/results-hero.png')] bg-cover bg-center bg-center">
            <div class="container p-2 mx-auto lg:pt-[10px] sm:pt-[10px] sm:pb-[80px] pt-[30px] pb-[50px]">
                <h1 class="text-6xl text-center font-regular text-gray-800 leading-tight md:leading-tight lg:leading-normal">
                    <?php echo e(devTranslate('page.Discover The Best','Ontdek de beste')); ?> <strong><?php echo e(devTranslate('page.Veterinary Clinics','Dieren klinieken')); ?> </strong>
                </h1>
            </div>
        </section>
        
        <section class="section section--search py-0 bg-transparent">
            <div class="container px-2 mx-auto bg-transparent">
                <form action="<?php echo e(route('results')); ?>" class="s-form md:p-[40px] z-30 p-[20px] flex flex-col md:flex-row px-[20px] items-center gap-y-4 md:gap-x-6 mt-[-50px] bg-white md:rounded-full border border-[#D2D3D4] relative before:hidden md:before:block before:absolute before:right-0 before:top-0 before:w-full md:before:w-1/4 before:h-full before:z-0 before:bg-primaryLight before:rounded-tr-full before:rounded-br-full">
                    <div class="w-full md:w-1/4 text-center md:text-left relative z-1">
                        <p class="mb-0 block xl-custom:block md:hidden">
                            <strong><?php echo e(devTranslate('page.What Are You Looking For?','Waar ben je naar opzoek?')); ?></strong>
                        </p>
                        <input name="zoeken" type="text" value="<?php echo e($_GET['zoeken'] ?? ""); ?>" placeholder="<?php echo e(devTranslate('page.Search For','Zoek naar')); ?>" class="form-control p-3 border border-none outline-none transition duration-300 ease-out w-full">
                    </div>

                    <div class="w-full md:w-1/4 text-center md:text-left relative lg:border-l lg:border-l-[#20242866] lg:px-[20px] ">
                        <p class="mb-0 hidden xl-custom:block"><strong><?php echo e(devTranslate('page.Category','Categorie')); ?></strong></p>
                        <div class="relative no-border">
                            <select name="categorie" class="no-border form-control p-3 border border-none outline-none transition duration-300 ease-out w-full appearance-none pr-10">
                                <option value=""><?php echo e(__('Maak een keuze')); ?></option>
                                <?php if(!empty($categories)): ?>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>" <?php if(isset($_GET['categorie']) && $_GET['categorie'] == $category->id): ?> selected="selected" <?php endif; ?>><?php echo e($category->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </select>
                            <i class="fa-solid fa-chevron-down absolute right-4 top-1/2 -translate-y-1/2 text-gray-600"></i>
                        </div>
                    </div>

                    <div class="w-full md:w-1/4 text-center md:text-left relative lg:border-l lg:border-l-[#20242866] lg:px-[20px]">
                        <p class="mb-0 hidden xl-custom:block"><strong><?php echo e(devTranslate('page.Location','Lokatie')); ?></strong></p>
                        <div class="relative noborder">
                            <select  name="stad" id="city-select" class="noborder form-control p-3 border border-none outline-none transition duration-300 ease-out w-full appearance-none pr-10">
                                <option value=""><?php echo e(devTranslate('page.Select a city','Selecteer een stad')); ?></option>
                                
                            </select>
                            <i class="fa-solid fa-chevron-down absolute right-4 top-1/2 -translate-y-1/2 text-gray-600"></i>
                        </div>
                    </div>

                    <div class="w-full md:w-1/4 text-center flex items-center justify-end relative z-1">
                        <span class="hidden md:inline-block search-span font-bold mr-8 text-lg"><?php echo e(devTranslate('page.Search','Zoeken')); ?></span>
                        <button type="submit" class="btn btn-secondary text-3xl md:text-5xl p-4 md:p-[20px] md:rounded-full w-full md:w-fit">
                            <i class="fa-regular fa-magnifying-glass"></i>
                        </button>
                    </div>
                </form>
            </div>
        </section>

        <section class="section section--clinics">
            <div class="container p-2 mx-auto relative">
                <?php echo $__env->make('parts.breadcrumb' , ['breadcrumbs' => $breadcrumbData ?? ''] , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <div class="section__header md:flex items-center justify-between mb-8">
                    <div>
                        <h4 class="subtitle w-fit text-md relative before:content-['']">
                        <?php echo e(devTranslate('page.Search Results:','Zoek Resultaten:')); ?>  <strong><?php echo e($vets->total()); ?> <?php echo e(devTranslate('page.Clinics','Dierenarsten')); ?></strong>
                        </h4>
                    </div>
                    <div class="flex mt-4 md:mt-0">
                        <div class="relative ml-auto">
                           
                        </div>
                        <div class="relative ml-2">
                           
                        </div>

                        <button id="btn-2cols" class="w-[45px] h-[45px] flex items-center justify-center rounded-full border border-gray-300 text-gray-400 transition duration-300 ease-out hover:text-black hover:border-black ml-2">
                            <i class="fa-solid fa-ellipsis-vertical"></i>
                        </button>
                        <button id="btn-4cols" class="w-[45px] h-[45px] flex items-center justify-center rounded-full border border-gray-300 text-gray-400 transition duration-300 ease-out hover:text-black hover:border-black ml-2">
                            <i class="fa-solid fa-ellipsis-vertical"></i><i class="fa-solid fa-ellipsis-vertical ml-1"></i>
                        </button>
                        <button id="btn-6cols" class="w-[45px] h-[45px] flex items-center justify-center rounded-full border border-gray-300 text-gray-400 transition duration-300 ease-out hover:text-black hover:border-black ml-2">
                            <i class="fa-solid fa-ellipsis-vertical"></i><i class="fa-solid fa-ellipsis-vertical ml-1"></i><i class="fa-solid fa-ellipsis-vertical ml-1"></i>
                        </button>
                    </div>
                </div>
                <div class="grid grid-cols-4 gap-4 mb-8 pt-2">
                <div class="categories-sidebar col-span-4 lg:col-span-1 bg-white border border-gray-300 p-[20px] h-fit" >
                    <h3 class="title title--sidebar title title--section font-bold text-2xl text-gray-800 mb-2">
                        <?php echo e(devTranslate('page.Search Category','Doorzoek categorie')); ?>

                    </h3>
                    <ul class="mb-4">
                        <?php 
                            $teller = 1;
                        ?>
                        <?php if(!empty($categories)): ?>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="text-xl mb-3 font-semibold border-t border-t-gray-300 py-3"><span class="text-primary">0<?php echo e($teller); ?></span> <a href="?categorie=<?php echo e($item->id); ?>" <?php if(isset($_GET['categorie']) && $_GET['categorie'] == $item->id): ?> class="text-primary" <?php endif; ?> ><?php echo e($item -> name); ?></a></li>
                                <?php $teller++; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </ul>
                    <a href="#" class="btn btn-primaryLight mx-auto block w-fit">
                       <?php echo e(devTranslate('page.View All Categories','Bekijk alle categorieën')); ?>

                    </a>
                </div>
                <div class="posts col-span-4 lg:col-span-3 grid grid-cols-3 gap-4" id="categories_posts">
                 <?php if(!empty($vets[0])): ?>
                    <?php $teller = 1; ?>   
                    <?php $__currentLoopData = $vets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="block-hotspots bg-white border border-gray-300 transition duration-300 ease-out hover:shadow-lg ">
                            <figure class="m-0 overflow-hidden">
                                <!-- Replace the static image with one based on your vet data or use a default image -->
                                <a href="<?php echo e(route('profile', ['slug' => slugify($vet->name) , 'id' => $vet->id])); ?>">
                                    <?php if(!empty($vet->featuredImage->name)): ?>
                                        <img class="w-full transition-transform duration-300 ease-out hover:scale-105"  src="<?php echo e(asset('storage/uploads/' . $vet->featuredImage->name)); ?>" alt="<?php echo e($vet->name); ?>">
                                    <?php else: ?>
                                    <img class="w-full transition-transform duration-300 ease-out hover:scale-105"  
                                        src="<?php echo e(asset('dieren/src/public/img/post-' . $teller . '.png')); ?>" 
                                        alt="<?php echo e($vet->name); ?>">
                                    <?php endif; ?>
                                    <!-- Assuming you have a route to view vet details -->  
                                    
                                </a>
                            </figure>
                            <div class="content p-[20px]">
                                <h3 class="title font-bold text-lg">
                                    <!-- Assuming you have a route to view vet details -->
                                    <a href="<?php echo e(route('profile', ['slug' => slugify($vet->name) , 'id' => $vet->id])); ?>"><?php echo e($vet->name); ?></a>
                                </h3>
                                <h4 class="subtitle text-sm text-gray-800 mb-2"><?php echo e($vet->excerpt); ?></h4>
                                <p class="location text-sm mb-0 font-semibold">
                                    <i class="fa-solid fa-location-dot text-primary"></i>
                                    <?php echo e($vet->zipcode); ?> <?php echo e($vet->street); ?> <?php echo e($vet->street_nr); ?> <br/><?php echo e($vet->city->name); ?>, Nederland
                                </p>
                                <a class="text-sm font-semibold" href="tel:<?php echo e($vet->phone); ?>">
                                    <i class="fa-solid fa-phone text-primary"></i> <?php echo e($vet->phone); ?>

                                </a>
                                <h4 class="price font-bold text-lg mt-2">
                                    <?php echo render_stars($vet->rating); ?>

                  
                                    <a class="float-right text-sm font-normal underline hover:text-primary" 
                                    href="<?php echo e(route('profile', ['slug' => slugify($vet->name) , 'id' => $vet->id])); ?>"> <?php echo e(devTranslate('page.View more','Bekijk meer ')); ?> </a>
                                </h4>
                            </div>
                        </div>
                        <?php $teller++; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <div class="text-center py-10 text-gray-500">
                    <p class="text-lg font-semibold"><?php echo e(devTranslate('page.No veterinarians found','Geen dierenartsen gevonden.')); ?></p>
                </div>
                <?php endif; ?>    
                </div>
                </div>
                <div class="pagination flex justify-center gap-2">
                    <?php echo e($vets->appends(request()->query())->links('vendor.pagination.custom')); ?>

                </div>
                <img src="public/img/bg-blocks.png" alt="" class="absolute bottom-[-80px] left-[-60px] z-[-1]"> 
            </div>
            <script>
                document.addEventListener("DOMContentLoaded", function () {
                    const postsContainer = document.querySelector(".posts");
                    const btn2Cols = document.getElementById("btn-2cols");
                    const btn4Cols = document.getElementById("btn-4cols");
                    const btn6Cols = document.getElementById("btn-6cols");

                    btn2Cols.addEventListener("click", () => {
                        postsContainer.classList.remove("grid-cols-3", "grid-cols-2");
                        postsContainer.classList.add("grid-cols-1");
                    });

                    btn4Cols.addEventListener("click", () => {
                        postsContainer.classList.remove("grid-cols-1", "grid-cols-3");
                        postsContainer.classList.add("grid-cols-2");
                    });

                    btn6Cols.addEventListener("click", () => {
                        postsContainer.classList.remove("grid-cols-1", "grid-cols-2");
                        postsContainer.classList.add("grid-cols-3");
                    });
                });
            </script>
        </section>

        <section class="section section--categories bg-[url('../../../src/public/img/categories.jpg')] bg-cover bg-center pt-[40px] pb-[50px] lg:pt-[80px] lg:pb-[100px]">
            <div class="container p-2 mx-auto">
                <div class="section__header flex flex-col lg:flex-row items-center justify-between mb-6">
                    <div>
                        <h4 class="subtitle w-fit text-md font-semibold relative before:content-[''] before:w-[20px] before:h-[2px] before:bg-primary before:absolute before:right-[-30px] before:top-1/2 before:-translate-y-1/2 leading-tight md:leading-tight lg:leading-normal">
                            <?php echo e(devTranslate('page.Choose Your Category','Kies een categorie')); ?>

                        </h4>
                        <h3 class="title title--section font-bold text-3xl text-gray-800">
                            <span class="text-primary"><?php echo e(devTranslate('page.Browse','Doorzoek')); ?></span> <?php echo e(devTranslate('page.Categories','de Categorieën')); ?>

                        </h3>
                    </div>
                </div>
                <div class="categories grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
                    <a href="<?php echo e(route('results')); ?>?categorie=1">
                        <div class="category border-2 border-white shadow-lg bg-white transition-transform duration-300 ease-out hover:scale-y-105">
                            <figure class="bg-gray-300 w-full h-[170px] flex overflow-hidden">
                                <img class="m-auto w-[120px] h-[120px]" src="<?php echo e(asset('dieren/src/public/img/dog.png')); ?>" alt="">
                            </figure>
                            <div class="content text-center p-4">
                                <h3 class="title text-md font-semibold mb-2"><?php echo e(devTranslate('page.Dogs', 'Honden')); ?></h3>
                                <p class="paragraph text-sm">(<?php echo e($categoriesForCount[0]['veterinarians_count']); ?> <?php echo e(devTranslate('page.Vermeldingen','Vermeldingen')); ?>)</p>
                            </div>
                        </div>
                    </a>

                    <a href="<?php echo e(route('results')); ?>?categorie=2">
                        <div class="category border-2 border-white shadow-lg bg-white transition-transform duration-300 ease-out hover:scale-y-105">
                            <figure class="bg-gray-300 w-full h-[170px] flex overflow-hidden">
                                <img class="m-auto w-[120px] h-[120px]" src="<?php echo e(asset('dieren/src/public/img/cat.png')); ?>" alt="">
                            </figure>
                            <div class="content text-center p-4">
                                <h3 class="title text-md font-semibold mb-2"><?php echo e(devTranslate('page.Cats', 'Katten')); ?></h3>
                                <p class="paragraph text-sm">(<?php echo e($categoriesForCount[1]['veterinarians_count']); ?> <?php echo e(devTranslate('page.Vermeldingen','Vermeldingen')); ?>)</p>
                            </div>
                        </div>
                    </a>

                    <a href="<?php echo e(route('results')); ?>?categorie=3">
                        <div class="category border-2 border-white shadow-lg bg-white transition-transform duration-300 ease-out hover:scale-y-105">
                            <figure class="bg-gray-300 w-full h-[170px] flex overflow-hidden">
                                <img class="m-auto w-[120px] h-[120px]" src="<?php echo e(asset('dieren/src/public/img/turtle.png')); ?>" alt="">
                            </figure>
                            <div class="content text-center p-4">
                                <h3 class="title text-md font-semibold mb-2"><?php echo e(devTranslate('page.Others', 'Overige')); ?></h3>
                                <p class="paragraph text-sm">(<?php echo e($categoriesForCount[2]['veterinarians_count']); ?> <?php echo e(devTranslate('page.Vermeldingen','Vermeldingen')); ?>)</p>
                            </div>
                        </div>
                    </a>    

                    <a href="<?php echo e(route('results')); ?>?categorie=4">
                        <div class="category border-2 border-white shadow-lg bg-white transition-transform duration-300 ease-out hover:scale-y-105">
                            <figure class="bg-gray-300 w-full h-[170px] flex overflow-hidden">
                                <img class="m-auto w-[120px] h-[120px]" src="<?php echo e(asset('dieren/src/public/img/shelters.png')); ?>" alt="">
                            </figure>
                            <div class="content text-center p-4">
                                <h3 class="title text-md font-semibold mb-2"><?php echo e(devTranslate('page.Shelters', 'Asielen')); ?></h3>
                                <p class="paragraph text-sm">(<?php echo e($categoriesForCount[3]['veterinarians_count']); ?> <?php echo e(devTranslate('page.Vermeldingen','Vermeldingen')); ?>)</p>
                            </div>
                        </div>
                    </a>    

                    <a href="<?php echo e(route('results')); ?>?categorie=5">
                    <div class="category border-2 border-white shadow-lg bg-white transition-transform duration-300 ease-out hover:scale-y-105">
                        <figure class="bg-gray-300 w-full h-[170px] flex overflow-hidden">
                            <img class="m-auto w-[120px] h-[120px]" src="<?php echo e(asset('dieren/src/public/img/specialists.png')); ?>" alt="">
                        </figure>
                        <div class="content text-center p-4">
                            <h3 class="title text-md font-semibold mb-2"><?php echo e(devTranslate('page.Specialists', 'Specialisten')); ?></h3>
                            <p class="paragraph text-sm">(<?php echo e($categoriesForCount[4]['veterinarians_count']); ?> <?php echo e(devTranslate('page.Vermeldingen','Vermeldingen')); ?>)</p>
                        </div>
                    </div>
                    </a>

                    <a href="<?php echo e(route('results')); ?>?categorie=6">
                        <div class="category border-2 border-white shadow-lg bg-white transition-transform duration-300 ease-out hover:scale-y-105">
                            <figure class="bg-gray-300 w-full h-[170px] flex overflow-hidden">
                                <img class="m-auto w-[120px] h-[120px]" src="<?php echo e(asset('dieren/src/public/img/emergencies.png')); ?>" alt="">
                            </figure>
                            <div class="content text-center p-4">
                                <h3 class="title text-md font-semibold mb-2"><?php echo e(devTranslate('page.Emergencies', 'Noodgevallen')); ?></h3>
                                <p class="paragraph text-sm">(<?php echo e($categoriesForCount[5]['veterinarians_count']); ?> <?php echo e(devTranslate('page.Vermeldingen','Vermeldingen')); ?>)</p>
                            </div>
                        </div>
                    </a>
            </div>
            </div>
        </section>

        <section class="section section--hotspots">
            <div class="container px-2 mx-auto relative">
                <div class="header-pills flex flex-wrap justify-center mb-6">
                    <button class="pill font-medium active border-b-4 border-b-primary px-4 sm:px-6 mb-2  hover:border-b-primary" data-filter="all"> <?php echo e(devTranslate('page.All','All')); ?></button>
                    <button class="pill font-medium border-b-2 border-b-[#D2D3D4] px-4 sm:px-6 mb-2  hover:border-b-primary" data-filter="best-rated"><?php echo e(devTranslate('page.Best Rated','Best beoordeeld')); ?></button>
                    <button class="pill font-medium border-b-2 border-b-[#D2D3D4] px-4 sm:px-6 mb-2  hover:border-b-primary" data-filter="most-viewed"><?php echo e(devTranslate('page.Most Viewed','Meest bekeken')); ?></button>
                </div>

                <div class="content-blocks grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                
                <?php if(!empty($bestVets)): ?>
                    <?php $teller = 4; ?>
                    <?php $__currentLoopData = $bestVets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="block-hotspots bg-white border border-gray-300 transition duration-300 ease-out hover:shadow-lg category-best-rated">
                            <figure class="m-0 overflow-hidden">
                                <a href="<?php echo e(route('profile', ['slug' => slugify($vet->name), 'id' => $vet->id])); ?>">
                                    <?php if(!empty($vet->featuredImage->name)): ?>
                                        <img class="w-full transition-transform duration-300 ease-out hover:scale-105"
                                            src="<?php echo e(asset('storage/uploads/' . $vet->featuredImage->name)); ?>"
                                            alt="<?php echo e($vet->name); ?>">
                                    <?php else: ?>
                                        <img class="w-full transition-transform duration-300 ease-out hover:scale-105"
                                            src="<?php echo e(asset('dieren/src/public/img/block-' . $teller . '.jpg')); ?>"
                                            alt="<?php echo e($vet->name); ?>">
                                    <?php endif; ?>
                                </a>
                            </figure>
                            <div class="content p-[20px]">
                                <h3 class="title font-bold text-lg">
                                    <a href="<?php echo e(route('profile', ['slug' => slugify($vet->name), 'id' => $vet->id])); ?>">
                                        <?php echo e($vet->name); ?>

                                    </a>
                                    <span class="rating float-right text-yellow-500 text-xs">
                                        <?php echo render_stars($vet->rating); ?>

                                    </span>
                                </h3>
                                <h4 class="subtitle text-sm text-gray-800 mb-2"><?php echo e($vet->excerpt); ?></h4>
                                <p class="location text-xs mb-0">
                                    <i class="fa-solid fa-location-dot text-primary"></i> <?php echo e($vet->zipcode); ?> <?php echo e($vet->street); ?>, Nederland
                                </p>
                                <a class="text-xs" href="tel:<?php echo e($vet->phone); ?>">
                                    <i class="fa-solid fa-phone text-primary"></i> <?php echo e($vet->phone); ?>

                                </a>
                                <h4 class="price font-bold text-lg mt-2">
                                    
                                    <a class="float-right text-sm font-normal underline hover:text-primary"
                                    href="<?php echo e(route('profile', ['slug' => slugify($vet->name), 'id' => $vet->id])); ?>">
                                        <?php echo e(devTranslate('page.View more','Bekijk meer ')); ?>

                                    </a>
                                </h4>
                                <br/>
                            </div>
                        </div>
                        <?php $teller++; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                
                <?php if(!empty($mostViewedVets)): ?>
                    <?php $teller = 4; ?>
                    <?php $__currentLoopData = $mostViewedVets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="block-hotspots bg-white border border-gray-300 transition duration-300 ease-out hover:shadow-lg category-most-viewed">
                            <figure class="m-0 overflow-hidden">
                                <a href="<?php echo e(route('profile', ['slug' => slugify($vet->name), 'id' => $vet->id])); ?>">
                                    <?php if(!empty($vet->featuredImage->name)): ?>
                                        <img class="w-full transition-transform duration-300 ease-out hover:scale-105"
                                            src="<?php echo e(asset('storage/uploads/' . $vet->featuredImage->name)); ?>"
                                            alt="<?php echo e($vet->name); ?>">
                                    <?php else: ?>
                                        <img class="w-full transition-transform duration-300 ease-out hover:scale-105"
                                            src="<?php echo e(asset('dieren/src/public/img/block-' . $teller . '.jpg')); ?>"
                                            alt="<?php echo e($vet->name); ?>">
                                    <?php endif; ?>
                                </a>
                            </figure>
                            <div class="content p-[20px]">
                                <h3 class="title font-bold text-lg">
                                    <a href="<?php echo e(route('profile', ['slug' => slugify($vet->name), 'id' => $vet->id])); ?>">
                                        <?php echo e($vet->name); ?>

                                    </a>
                                    <span class="rating float-right text-yellow-500 text-xs">
                                        <?php echo render_stars($vet->rating); ?>

                                    </span>
                                </h3>
                                <h4 class="subtitle text-sm text-gray-800 mb-2"><?php echo e($vet->excerpt); ?></h4>
                                <p class="location text-xs mb-0">
                                    <i class="fa-solid fa-location-dot text-primary"></i> <?php echo e($vet->zipcode); ?> <?php echo e($vet->street); ?> <?php echo e($vet->street_nr); ?> <br/> <?php echo e($vet->city->name); ?>, Nederland
                                </p>
                                <a class="text-xs" href="tel:<?php echo e($vet->phone); ?>">
                                    <i class="fa-solid fa-phone text-primary"></i> <?php echo e($vet->phone); ?>

                                </a>
                                <h4 class="price font-bold text-lg mt-2">
                                    
                                    <a class="float-right text-sm font-normal underline hover:text-primary"
                                    href="<?php echo e(route('profile', ['slug' => slugify($vet->name), 'id' => $vet->id])); ?>">
                                        <?php echo e(devTranslate('page.View more','Bekijk meer ')); ?>

                                    </a>
                                </h4>
                                <br/>
                            </div>
                        </div>
                        <?php $teller++; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

                </div>
                <img src="<?php echo e(asset('dieren/src/public/img/bg-blocks.png')); ?>" alt="" class="absolute top-[-80px] right-[-60px] z-[-1]">
            </div>
        </section>

        <section class="section section--about-us">
        <div class="container px-2 mx-auto">
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div>
                    <h3 class="adv title title--section text-4xl font-bold mb-8  leading-tight md:leading-tight lg:leading-normal">
                     <?php echo $advantages['title']; ?>   
                    </h3>
                    <div class="grid grid-cols-2 mb-3 pb-3 border-b border-b-gray-300">
                        <div class="number">
                            <h4 class="value text-primary font-medium text-4xl md:text-6xl">+1k</h4>
                            <p class="description text-gray-400"><?php echo e(devTranslate('page.Dierenartsen','Dierenartsen')); ?></p>
                        </div>
                        <div class="number">
                            <h4 class="value text-primary font-medium text-4xl md:text-6xl">+1k</h4>
                            <p class="description text-gray-400"><?php echo e(devTranslate('page.Plaatsen','Plaatsen')); ?></p>
                        </div>
                    </div>
                    <p class="paragraph text-gray-400 mb-4">
                        <?php echo $advantages['description']; ?>   
                    </p>
                    <ul>
                        <?php if(!empty($advantages['usp'])): ?>
                            <?php $__currentLoopData = $advantages['usp']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="font-medium mb-3">
                                    <i class="fa-regular fa-circle-check text-primary"></i> <?php echo e($item['usp']); ?>

                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </ul>
                </div>
                <div>
                    <figure class="w-full flex lg:justify-center">
                        <img class="max-w-full h-auto" src="<?php echo e(asset('dieren/src/public/img/Pics.png')); ?>" alt="">
                    </figure>
                </div>
            </div>
        </div>
    </section>
    </div>
    <?php $__env->startPush('scripts'); ?>
    <script>
  $(document).ready(function () {
    const selectedCity = "<?php echo e(request('stad')); ?>";
    // If a city is pre-selected, manually add it as an option
    if (selectedCity) {
      $('#city-select').append(new Option(selectedCity, selectedCity, true, true)).trigger('change');
    }

    // Now initialize select2
    $('#city-select').select2({
      language: "nl",
      placeholder: 'Zoek een stad',
      minimumInputLength: 2,
      ajax: {
        url: '/api/cities',
        dataType: 'json',
        delay: 300,
        data: function (params) {
          return {
            q: params.term
          };
        },
        processResults: function (data) {
          return {
            results: data.map(function (city) {
              return {
                id: city.name,
                text: city.name
              };
            })
          };
        },
        cache: true
      }
    });
  });
</script>
    <?php $__env->stopPush(); ?>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/dierenartsen/dierenartsen/resources/views/website/results.blade.php ENDPATH**/ ?>