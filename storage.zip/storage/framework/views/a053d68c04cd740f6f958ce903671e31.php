<div>
    
    <div class="main-container flex relative">
        <?php echo $__env->make('parts.company.sidebar', ['active' => $active ?? ""], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <div class="main-content flex-1 px-5 py-10 lg:p-16 max-w-[100%]">
            <div class="border border-solid border-[#CFD7E4] rounded-[15px] px-5 py-6 xl:px-16 xl:py-9">

                <div class="flex items-center mb-5 lg:mb-10">
                    <figure class="block relative w-[50px] h-[50px] min-w-[50px] lg:w-[70px] lg:h-[70px] rounded-full overflow-hidden border-2 border-solid border-[#d1d1d1] group-hover:border-primary duration-300 me-4"><img class="abs-cover" src="<?php echo e(asset('dieren-dashboard/src/public/img/user.jpg')); ?>" alt=""></figure>
                    <div>
                        <h2 class="font-medium text-xl lg:text-2xl text-[#271F30] mb-1"><?php echo e(__('Hallo')); ?>  <?php echo e(Auth::user()->name); ?>!</h2>
                        <p class="text-[#888888] mb-0"><?php echo e(devTranslate('dashboard_company.Bekijk hieronder de laatste ontwikkelingen op jouw bedrijfspagina','Bekijk hieronder de laatste ontwikkelingen op jouw bedrijfspagina')); ?></p>
                    </div>
                </div>

             

                <div class="panel-white bg-white py-4 px-5 lg:p-9 rounded-[8px]">
                    

                    <div class="pane-white__table h-[42vh] overflow-auto">
                        
                        <!--[if BLOCK]><![endif]--><?php if(!empty($claim)): ?>
                            <?php if (isset($component)) { $__componentOriginal504588023e91ca48b8add96960e6ab6b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal504588023e91ca48b8add96960e6ab6b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert-warning','data' => ['class' => 'my-4','id' => 'error-message']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert-warning'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'my-4','id' => 'error-message']); ?>
                                <?php echo e(__('Jouw account moet nog goedgekeurd worden. Goedkeuring vind meestal plaats binnen 24 uur.')); ?>

                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal504588023e91ca48b8add96960e6ab6b)): ?>
<?php $attributes = $__attributesOriginal504588023e91ca48b8add96960e6ab6b; ?>
<?php unset($__attributesOriginal504588023e91ca48b8add96960e6ab6b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal504588023e91ca48b8add96960e6ab6b)): ?>
<?php $component = $__componentOriginal504588023e91ca48b8add96960e6ab6b; ?>
<?php unset($__componentOriginal504588023e91ca48b8add96960e6ab6b); ?>
<?php endif; ?>
                        <?php else: ?>
                            <?php if (isset($component)) { $__componentOriginal7b0974eef90702e81393ad9c4326ee31 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b0974eef90702e81393ad9c4326ee31 = $attributes; } ?>
<?php $component = App\View\Components\Success::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('success'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Success::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4','id' => 'success-message']); ?>
                                <?php echo e(__('Om zoveel mogelijk nieuwe klanten te werken is het aan te raden jouw profiel zo volledig mogelijk te maken.')); ?>

                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b0974eef90702e81393ad9c4326ee31)): ?>
<?php $attributes = $__attributesOriginal7b0974eef90702e81393ad9c4326ee31; ?>
<?php unset($__attributesOriginal7b0974eef90702e81393ad9c4326ee31); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b0974eef90702e81393ad9c4326ee31)): ?>
<?php $component = $__componentOriginal7b0974eef90702e81393ad9c4326ee31; ?>
<?php unset($__componentOriginal7b0974eef90702e81393ad9c4326ee31); ?>
<?php endif; ?>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->


                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH /Applications/MAMP/htdocs/dierenartsen/dierenartsen/resources/views/livewire/company/dashboard.blade.php ENDPATH**/ ?>