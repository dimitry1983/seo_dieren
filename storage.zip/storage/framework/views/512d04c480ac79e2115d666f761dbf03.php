<?php if($paginator->hasPages()): ?>
    <div class="pagination flex justify-center gap-2 mt-6">
        
        <?php if($paginator->onFirstPage()): ?>
            <button class="w-10 h-10 flex items-center justify-center rounded-full border border-gray-300 text-lg font-semibold text-gray-400 bg-white cursor-not-allowed" disabled>
                <i class="fa-solid fa-arrow-left-long"></i>
            </button>
        <?php else: ?>
            <a href="<?php echo e($paginator->previousPageUrl()); ?>" class="w-10 h-10 flex items-center justify-center rounded-full border border-gray-300 text-lg font-semibold text-black bg-white hover:bg-primary hover:text-white transition duration-300 ease-out">
                <i class="fa-solid fa-arrow-left-long"></i>
            </a>
        <?php endif; ?>

        
        <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <?php if(is_string($element)): ?>
                <span class="w-10 h-10 flex items-center justify-center text-gray-400">...</span>
            <?php endif; ?>

            
            <?php if(is_array($element)): ?>
                <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($page == $paginator->currentPage()): ?>
                        <span class="w-10 h-10 flex items-center justify-center rounded-full border border-gray-300 text-lg font-semibold bg-primary text-white">
                            <?php echo e($page); ?>

                        </span>
                    <?php else: ?>
                        <a href="<?php echo e($url); ?>" class="w-10 h-10 flex items-center justify-center rounded-full border border-gray-300 text-lg font-semibold text-black bg-white hover:bg-primary hover:text-white transition duration-300 ease-out">
                            <?php echo e($page); ?>

                        </a>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
        <?php if($paginator->hasMorePages()): ?>
            <a href="<?php echo e($paginator->nextPageUrl()); ?>" class="w-10 h-10 flex items-center justify-center rounded-full border border-gray-300 text-lg font-semibold text-black bg-white hover:bg-primary hover:text-white transition duration-300 ease-out">
                <i class="fa-solid fa-arrow-right-long"></i>
            </a>
        <?php else: ?>
            <button class="w-10 h-10 flex items-center justify-center rounded-full border border-gray-300 text-lg font-semibold text-gray-400 bg-white cursor-not-allowed" disabled>
                <i class="fa-solid fa-arrow-right-long"></i>
            </button>
        <?php endif; ?>
    </div>
<?php endif; ?><?php /**PATH /Applications/MAMP/htdocs/dierenartsen/dierenartsen/resources/views/vendor/pagination/custom.blade.php ENDPATH**/ ?>