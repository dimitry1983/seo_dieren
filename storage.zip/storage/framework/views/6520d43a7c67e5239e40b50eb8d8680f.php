<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /Applications/MAMP/htdocs/dierenartsen/dierenartsen/resources/views/vendor/mail/text/header.blade.php ENDPATH**/ ?>